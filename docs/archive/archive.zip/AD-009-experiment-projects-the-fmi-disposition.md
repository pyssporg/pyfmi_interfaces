---
id: AD-009
title: Experiment projects the FMI disposition
summary: DefaultExperiment supplies startTime and stopTime, Experiment adds stepSize and tolerance, and each authored field is emitted while absence stays absent.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 03-implementation/model-description.md
artifacts:
  - src/pyfmi_sysml2/model_description/document.py
supersedes: []
superseded_by: []
related: [AD-006, AD-008]
---

## Context

`pycps_sysml2` split the experiment container by standard disposition:
`DefaultExperiment` now carries the SSP `startTime` and `stopTime`, and
`Experiment` adds the FMI `stepSize` and `tolerance`. FMI 2.0.5 defines all
four `DefaultExperiment` attributes as optional doubles with no default, so an
`Experiment` container does not require `stepSize`.

## Decision

`default_experiment` maps every field the typed container provides: `startTime`
and `stopTime` from the base `DefaultExperiment`, `stepSize` and `tolerance`
from the FMI fields the container provides. An unauthored field stays `None` and the
codec omits it; no container means no `DefaultExperiment` element. No field
receives a numeric default.

## Rationale

The FMI artifact owns the whole `fmi2:DefaultExperiment` element, so it should
read every field the FMI disposition provides and nothing the container does not
author. Mirroring the upstream split keeps one container usable by both
implementers without this generator reinterpreting the vocabulary.

## Alternatives Considered

- Require `stepSize` on an `Experiment`: contradicts FMI 2.0.5 optionality and
  rejects a valid model.
- Substitute a default for an absent field: invents a value the standard does
  not define.
- Read only the base `DefaultExperiment`: silently drops the FMI fields the
  vocabulary now provides.

## Consequences

- Positive: authored fields reach `modelDescription.xml`; a plain
  `DefaultExperiment` contributes start and stop only; absence stays absent.
- Negative: the `.ssd` of the same model drops `stepSize` and `tolerance`, so
  the two artifacts differ by those fields.
- Deliberate non-change: no experiment defaults and no FMI authoring attributes
  beyond the container are introduced.

## Verification

`tests/test_model_description.py` covers authored, partial, and absent
experiments; the minimal model-description golden pins the emitted element.

## Review Trigger

FMI revises the default-experiment fields, or SSP adopts `stepSize` or
`tolerance`.
