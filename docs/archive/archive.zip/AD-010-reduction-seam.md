---
id: AD-010
title: Generators consume a parser-free Reduction
summary: The dialect is read only by the reduction bridge; every generator accepts a Reduction and runs without importing pycps_sysml2, while paths and architectures still parse at the edge.
date: 2026-11-20
status: accepted
layers: [architecture, implementation]
state: 02-architecture/interface-reduction.md
artifacts:
  - src/pyfmi_sysml2/core/model.py
  - src/pyfmi_sysml2/core/reduction.py
  - src/pyfmi_sysml2/model_description/document.py
  - src/pyfmi_sysml2/c/headers.py
  - src/pyfmi_sysml2/c/runtime.py
  - src/pyfmi_sysml2/modelica/package.py
  - src/pyfmi_sysml2/__init__.py
supersedes: []
superseded_by: []
related: [AD-005]
---

## Context

Parsing and generation were entangled: every generator accepted an
`Architecture` or a path and called the dialect itself, `core/model.py`
imported the dialect's value formatter, and the `modelDescription` generator
read the experiment container directly. A downstream project needs to parse
SysML once and run the generators elsewhere, and to use the parse side without
the generators, so neither half should require the other's imports.

## Decision

`Reduction` is the parser-free value every generator accepts: the components,
`ExportIdentity`, package name, and `Experiment`. `to_reduction()` is the only
runtime reader of `pycps_sysml2`; it resolves, validates, formats
`Variable.start_text`, and returns the value. `core/model.py` imports no
dialect, and generators given a `Reduction` import none. Architectures and
paths still parse at the edge through `to_reduction()`.

## Rationale

The reduction is already the contract the generators share; naming it as a value
makes the contract explicit and transportable. Parsing stays at the edge
(`to_reduction`), the parse-side helpers (`components`, `fmu_units`,
`resolve_system`) remain available, and no existing call site has to change
because the old inputs are still accepted.

## Alternatives Considered

- Import-only laziness: `import pyfmi_sysml2` would not load the dialect, but a
  generator still could not run without it, so the downstream split stays
  blocked.
- A separate parser package or distribution: duplicates the package boundary
  and contradicts the one-package module map; a second installable is heavier
  than the seam needs.
- Make generators reduction-only and remove path inputs: breaks the public
  surface and every CLI handler for no additional decoupling.

## Consequences

- Positive: a generator run from a `Reduction` needs no `pycps_sysml2` import;
  the dialect is confined to one module and guarded by a static test; a
  reduction can be built once and reused across generators.
- Negative: `Variable.start` became `Variable.start_text`, so hand-built
  variables now carry the formatted text; `pycps_sysml2` stays a declared
  dependency, so installing the package still installs the dialect.
- Deliberate non-change: the parser-side API (`components`, `fmu_units`,
  `resolve_system`, `architecture`) and the CLI keep their signatures and path
  inputs.

## Verification

`tests/test_reduction_seam.py` compares every generator's bytes from a path and
from a `Reduction` and runs them with a blocked `pycps_sysml2` import.
`tests/test_layering.py` asserts only `core/reduction.py` imports the dialect at
runtime; the full suite and the goldens are unchanged.

## Review Trigger

Re-open when a generator needs a parser-only fact the `Reduction` does not
carry, or when `pycps_sysml2` stops being a hard install dependency.
