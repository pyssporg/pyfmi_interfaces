---
id: AD-006
title: Read the default experiment from a typed container, not control tags
summary: The dialect's 0.3.0 release removed every pyssp_* control tag, so the modelDescription reads its DefaultExperiment through read_experiment, the reduction skips typed containers by classify_attribute, and the flat-connector refusal and control filters are deleted.
date: 2026-11-19
status: accepted
layers: [architecture, product]
state: docs/breakdown/03-implementation/model-description.md
artifacts:
  - src/pyfmi_sysml2/model_description/document.py
  - src/pyfmi_sysml2/core/reduction.py
  - src/pyfmi_sysml2/__init__.py
  - tests/test_model_description.py
  - tests/test_fixture_policy.py
  - tests/fixtures/README.md
  - tests/fixtures/applied/applied.sysml
  - tests/fixtures/applied/case.md
supersedes: []
superseded_by: []
related: [CP-002, CP-003, INFO-003, INFO-005, INFO-017, AD-005]
---

# AD-006: Read the default experiment from a typed container, not control tags

## Context

`pycps_sysml2` 0.3.0 removed the `pyssp_*` attribute vocabulary: a special datum
is recognized by its container's type, never by its name. `core.CONTROL`,
`ControlAttributes`, `DEFAULT_START_ATTR`, `DEFAULT_STOP_ATTR`,
`FLAT_CONNECTOR_ATTR`, `DialectPolicy.control`, and the flat-connector `port
def` rule are gone; `core.control` keeps only the migration error.

This package read the retired start/stop tags in `model_description/document.py`
and kept a control-name filter and a flat-connector refusal in `core/reduction.py`.

## Decision

`DefaultExperiment` comes from
`metadata.roles.read_experiment(architecture, system, required=False)`:
`startTime`/`stopTime` always, `stepSize` only when declared, no container means
no element. Port fields are filtered by `classify_attribute`: the four container
kinds are skipped, `TYPED` and `UNTYPED` stay fields. The control filters and the
flat-connector refusal are deleted, and the version bumps to 0.3.0.

## Rationale

One owner per rule: the container type, the resolution, and the migration error
all live in `pycps_sysml2`. Re-declaring a name here would be the second copy the
one-dialect-owner commitment forbids, and reading an attribute by name is what
0.3.0 makes impossible. `classify_attribute` states the skip rule once, where a
prefix test only guessed.

## Alternatives Considered

- Keep a local `pyssp_` prefix filter as a no-op: it re-declares the retired
  vocabulary and hides which attribute kinds are containers.
- Skip every `TYPED` attribute: a resolved type on a port is not necessarily
  metadata; the four known container kinds are the rule.

## Consequences

- Positive: the element follows the container's type and carries `stepSize`; the
  reduction has one skip rule and no retired-name knowledge.
- Negative: `pyproject.toml` still pins the v0.2.0 dialect wheel, which lacks the
  0.3.0 API; re-pinning waits for the release asset (`IMP-002`).
- Neutral: an architecture without an experiment container produces the same
  bytes as before, and the public facade is unchanged. The inline applied-set
  model literal moved to `tests/fixtures/applied/` because it outgrew the
  test-literal rule.

## Verification

`python3 -m pytest -q` reports 254 passed and the two known console-script
failures, unchanged from the baseline. `tests/test_model_description.py` covers
both mappings, the omitted `stepSize`, the absent container, and the retired-tag
refusal; every golden is unchanged.

## Review Trigger

Revisit when the dialect changes the experiment container again, when an FMI
authoring attribute becomes part of the contract, or when the dialect pin is
re-cut.
