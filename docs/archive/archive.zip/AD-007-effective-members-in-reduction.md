---
id: AD-007
title: FMI reduction reads effective members
summary: The component reduction resolves inherited parameters, ports, and parts through pycps_sysml2 before any generator runs.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/interface-reduction.md
artifacts:
  - src/pyfmi_sysml2/core/reduction.py
supersedes: []
superseded_by: []
related: [AD-003]
---

## Context

`pycps_sysml2` resolves specialization on demand and leaves the IR
source-faithful. An FMI component must export the interface its definition
actually exposes, including members inherited from a base definition.

## Decision

`core/reduction.py` reads `pycps_sysml2.model.effective.effective_members`
whenever it enumerates attributes, ports, or parts, so inherited parameters,
port fields, and subparts are reduced like declared ones. The generators consume
only the reduction. Inheritance is resolved on demand, never materialized at
load; an unknown or wrong-kind supertype is skipped silently.

## Rationale

The reduction is the single source of the variable set. If it read declared
members only, an inherited port field would vanish from every artifact while the
SSD exported it, splitting the two implementers on the same model.

## Alternatives Considered

- Reduce declared members and let each generator expand inheritance: the
  generators would re-derive the variable set, which the one-variable-set rule
  forbids.
- Flatten the architecture before reduction: duplicate state and a second
  inheritance rule in this package.

## Consequences

Positive: FMI artifacts agree with the effective SysML interface, and the
reduction stays the only place that decides which variables exist. Negative: the
reduction inherits the unknown-supertype gap, and a skipped base silently drops
members from the artifact.

## Verification

The inheritance reduction tests pin that an inherited parameter and port field
reach `modelDescription.xml`; the built-artifact goldens compare byte-for-byte.

## Review Trigger

A generator needs a member fact the reduction does not carry, or the analyzer
starts reporting unknown supertypes.
