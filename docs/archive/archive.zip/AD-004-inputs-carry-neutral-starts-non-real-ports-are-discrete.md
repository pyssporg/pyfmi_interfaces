---
id: AD-004
title: Inputs carry neutral starts; non-Real ports are discrete
summary: FMI 2.0 requires an input start and forbids continuous variability for non-Real types, so the reduction emits 0/false/"" starts and discrete variability.
date: 2026-11-17
status: accepted
layers: [product]
state: docs/breakdown/01-product/variable-model.md
artifacts:
  - src/pyfmi_sysml2/interface.py
  - tests/test_model_description.py
  - tests/test_fmpy_load.py
supersedes: []
superseded_by: []
related: [CP-002, AD-002]
---

# AD-004: Inputs carry neutral starts; non-Real ports are discrete

## Context

Headless pipe ports were emitted with the schema default `variability` and no
`start`. fmpy's FMI 2.0 validator refused the document twice: `Integer`,
`Boolean`, and `String` variables may not be `continuous`, and every `input`
must carry a start value. The SysML dialect authors no input defaults, so the
reduction had nothing to copy. A consumer that only used the in-repo validator
would still have produced a document another FMI tool refuses.

## Decision

The reduction gives every input the neutral start of its primitive (`0`, `0`,
`false`, `""`) and marks every non-`Real` port field `variability="discrete"`.
`Real` port fields keep the continuous default, and outputs carry no start.
The rule lives in `component_interface`, so every artifact sees the same set.

## Rationale

The validator's rules are FMI 2.0 semantics, not one tool's preference.
Authoring neither value would force every consumer to patch the XML, which the
one-variable-set commitment forbids. The neutral zero is the only value the
dialect can justify without inventing a default it does not own; refusing the
model would reject architectures that are valid SysML.

## Alternatives Considered

- Refuse an input without an authored default: rejects valid SysML and pushes
  the decision onto the dialect owner.
- Emit `<Real start="0" />` only for `Real` and leave others bare: keeps the
  fmpy failure for Integer, Boolean, and String.
- Let consumers patch or override the modelDescription: breaks the one
  variable set and the artifact boundary.
- Mark every port discrete: changes Real semantics and the continuous
  contract for no FMI reason.

## Consequences

- Positive: the document passes an independent FMI 2.0 validator; inputs have
  a defined pre-first-step value; the rule is shared by XML, runtime, and
  headers.
- Negative: a zero start can hide a consumer that forgets to set an input; the
  value is a convention, not authored intent.
- Neutral: outputs still carry no start, which FMI permits.

## Verification

`tests/test_model_description.py` asserts the exact causality, variability, and
start tuples. `tests/test_fmpy_load.py` runs fmpy's validator over every
fixture's modelDescription and loads, steps, and reads a packaged FMU.

## Review Trigger

Revisit when the dialect gains input defaults or per-variable variability, or
when the authoring-attribute work (v0.2.0) makes starts explicit.
