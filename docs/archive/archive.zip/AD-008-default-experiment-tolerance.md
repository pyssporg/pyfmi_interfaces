---
id: AD-008
title: DefaultExperiment tolerance is emitted only when authored
summary: The modelDescription maps startTime and stopTime always, stepSize and tolerance only when the container declares them; absence stays absent and no numeric default is invented.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 03-implementation/model-description.md
artifacts:
  - src/pyfmi_sysml2/model_description/document.py
supersedes: []
superseded_by: []
related: [AD-006]
---

## Context

`pycps_sysml2` exposes an optional `tolerance` on the shared
`DefaultExperiment` container, read from the effective-member view. This
generator already maps the container onto the FMI 2.0 `DefaultExperiment`
element field by field, and FMI 2.0.5 defines every field as an optional double
with no default.

## Decision

`default_experiment` passes `tolerance=experiment.tolerance` to
`Fmi2DefaultExperiment`. The installed `pyssp_standard` dataclass carries
`tolerance: float | None = None`; the codec renders the value with `str(value)`
(for example `tolerance="1e-06"`) and omits the attribute entirely when it is
`None`. `startTime` and `stopTime` stay always emitted, `stepSize` stays
conditional, and no field receives a numeric default.

## Rationale

The attribute is authored data with a standard carrier, so binding it is a
one-field mapping and keeps the SysML container and the FMI element from
disagreeing. Inventing a tolerance default would hide an unauthored model and
contradict the rule the other experiment fields follow.

## Alternatives Considered

- Leave tolerance unbound and let pyfmi read a private attribute: re-declares a
  standard field outside the dialect owner and splits the two implementers.
- Default tolerance to an FMI constant: invents a value the standard does not
  set.
- Put tolerance only on `Experiment`: a plain `DefaultExperiment` could not
  carry an FMI tolerance.

## Consequences

- Positive: an authored tolerance reaches `modelDescription.xml`, and an
  unauthored one leaves the element unchanged.
- Negative: SSP 2.0 has no experiment tolerance, so the SSD path intentionally
  drops the value; the two artifacts can differ by that one field.
- Deliberate non-change: FMI authoring attributes — guid policy, modelName
  override, capabilities, units, and declared causality — remain non-goals.

## Verification

`tests/test_model_description.py` covers an authored tolerance (parsed and
XSD-validated) and an absent one; the full suite's remaining failures are the
known environment set, not this field.

## Review Trigger

FMI revises the default-experiment fields, or SSP gains a tolerance attribute.
