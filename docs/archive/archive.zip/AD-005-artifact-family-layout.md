---
id: AD-005
title: Split the package into artifact families under one core
summary: Generators move into c, model_description, modelica, and fmu subpackages that depend only on core, which keeps one reduction and one spelling table; the CLI is a thin dispatcher over family registries.
date: 2026-11-17
status: accepted
layers: [architecture]
state: docs/breakdown/02-architecture/module-map.md
artifacts:
  - src/pyfmi_sysml2/core/model.py
  - src/pyfmi_sysml2/core/reduction.py
  - src/pyfmi_sysml2/core/spelling.py
  - src/pyfmi_sysml2/core/identity.py
  - src/pyfmi_sysml2/c/headers.py
  - src/pyfmi_sysml2/c/runtime.py
  - src/pyfmi_sysml2/model_description/document.py
  - src/pyfmi_sysml2/modelica/package.py
  - src/pyfmi_sysml2/fmu/archive.py
  - tests/test_layering.py
supersedes: []
superseded_by: []
related: [INFO-017, AD-003]
---

# AD-005: Split the package into artifact families under one core

## Context

The package was flat: one module per artifact, `interface.py` for the reduction,
`headers.py` and `package.py` for support, and one `cli.py` that owned every
subcommand's arguments. Adding an artifact type meant editing the flat
namespace, the one CLI parser, and a shared module that also held C, C++, and
Modelica spelling tables. The flat layout passed the layering test only because
that test globbed top-level files; nothing enforced a boundary between
artifacts.

## Decision

The tree splits by artifact: `core/` owns the model, reduction, identity,
CLI registry, and one spelling module; `c/`, `model_description/`,
`modelica/`, and `fmu/` own their emitters and `COMMANDS`. Only `__init__.py`
and `cli.py` import families; families import `core/` and themselves. Old
paths are deleted, not shimmed; facade and command names are unchanged.

## Rationale

An artifact type is the unit that grows: a family adds a directory, emitters,
a `COMMANDS` tuple, and one line in `cli.py`. Reduction and spelling stay in
one place because they keep artifacts from disagreeing (`INFO-017`);
distributing them would trade one import for divergent copies. The layering
test, not convention, enforces the shape.

## Alternatives Considered

- Keep the flat package and add modules as needed: no boundary, and the CLI
  parser keeps growing with every artifact.
- Put a generator under each family but move spelling tables with it: each
  artifact could drift on a primitive's spelling, breaking the one-variable-set
  commitment.
- Keep re-export modules at the old paths: thin wrappers the contributor
  guidelines reject in experimental software.
- Discover families by scanning directories or entry points: implicit and hard
  to review; one explicit dispatcher line is clearer.

## Consequences

- Positive: a new artifact type is a self-contained unit; cross-family coupling
  is impossible by construction; the layering test now covers every module.
- Negative: module paths change once, so imports in downstream code and in
  hand-written notes must be updated; two files named `package.py`
  (`modelica/`, `fmu/`) rely on qualified imports to stay distinct.
- Neutral: the facade and CLI surface are unchanged, so consumers of the five
  generators see no difference.

## Verification

`tests/test_layering.py` enforces core purity, family isolation, top-level-only
family collection, registration completeness against the family directories,
module reachability, docstrings, facade shape, and the Python floor. Each rule
was proven to fail on an injected violation in a scratch copy. The full suite
passes unchanged against byte-identical goldens, and the CLI help and every
subcommand help are byte-identical to the pre-split output.

## Review Trigger

Revisit when a family needs a second reduction or a shared primitive, when a
second consumer of `core/cli.py` appears, or when the artifact set grows enough
that `cli.py`'s explicit registry becomes the bottleneck.
